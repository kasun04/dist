

Using WSO2 ESB Development Tool
===============================

1. ESB Solution project