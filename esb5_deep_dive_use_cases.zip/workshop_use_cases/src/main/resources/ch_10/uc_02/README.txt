



Local File -> ESB:message->log

